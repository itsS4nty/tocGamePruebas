<?php

function enviarTabla($Tabla) {
	global $Cliente;
	global $Conn;
	
/*
	$res = odbc_prepare($Conn, "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_CATALOG=? AND TABLE_NAME=?"); 
	$bool = odbc_execute($res, array("G_Gtpv", $Tabla));
	if (!$bool) enviarError(9);
*/
	$res = odbc_prepare($Conn, "SELECT * FROM ?"); 
	$bool = odbc_execute($res, array($Cliente["prefijo"].$Tabla));
	if (!$bool) enviarError(10); 
	
	enviarSql("CREATE TABLE	
		
}

function sincronizarTablas() {
	global $Cliente;
	global $Conn;
	
	$res = odbc_prepare($Conn, "SELECT TABLA FROM G_TABLAS_SINCRONIA WHERE PRODUCTO=? AND VERSION=?"); 
	$bool = odbc_execute($res, array($Cliente["producto"], $Cliente["version"]));
	if (!$bool) enviarError(8); // si no hay G_TABLAS_SINCRONIA todo sincronizado ??
	
	while (odbc_fetch_row($res)) {
		$Tabla = odbc_result($res, "TABLA");
		enviarTabla($Tabla);
	}
}

?>